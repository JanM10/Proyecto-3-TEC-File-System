var searchData=
[
  ['_7ewidget_5',['~Widget',['../class_widget.html#aa24f66bcbaaec6d458b0980e8c8eae65',1,'Widget']]]
];
