var searchData=
[
  ['texto_12',['texto',['../class_widget.html#a8b5c6cb1e2b1485e93102898a3a2b838',1,'Widget']]]
];
