var searchData=
[
  ['widget_8',['Widget',['../class_widget.html',1,'']]]
];
