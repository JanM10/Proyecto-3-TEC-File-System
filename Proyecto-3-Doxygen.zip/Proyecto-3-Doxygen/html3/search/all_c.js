var searchData=
[
  ['openelement_78',['OpenElement',['../classtinyxml2_1_1_x_m_l_printer.html#a20fb06c83bd13e5140d7dd13af06c010',1,'tinyxml2::XMLPrinter']]],
  ['operator_28_29_79',['operator()',['../structcomparar.html#a04e0efb4cd7a2b4ca2c6ac416f1f613f',1,'comparar']]],
  ['operator_3d_80',['operator=',['../classtinyxml2_1_1_x_m_l_handle.html#a75b908322bb4b83be3281b6845252b20',1,'tinyxml2::XMLHandle']]]
];
