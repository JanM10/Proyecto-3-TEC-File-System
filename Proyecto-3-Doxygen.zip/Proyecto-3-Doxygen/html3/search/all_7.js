var searchData=
[
  ['hasbom_44',['HasBOM',['../classtinyxml2_1_1_x_m_l_document.html#a33fc5d159db873a179fa26338adb05bd',1,'tinyxml2::XMLDocument']]],
  ['hostname_45',['hostname',['../class_connection_dialog.html#a66e409cfac43495046b93a9046d2e13c',1,'ConnectionDialog']]]
];
