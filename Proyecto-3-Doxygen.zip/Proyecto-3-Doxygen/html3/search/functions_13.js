var searchData=
[
  ['widget_319',['Widget',['../class_widget.html#ace1aa23652eb4425355a81760b39fd37',1,'Widget']]]
];
