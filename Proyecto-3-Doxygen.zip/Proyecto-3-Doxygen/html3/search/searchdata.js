var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwx~",
  1: "cdemnswx",
  2: "abcdefghilnopqrstuvwx~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

