var searchData=
[
  ['widget_144',['Widget',['../class_widget.html',1,'Widget'],['../class_widget.html#ace1aa23652eb4425355a81760b39fd37',1,'Widget::Widget()']]]
];
