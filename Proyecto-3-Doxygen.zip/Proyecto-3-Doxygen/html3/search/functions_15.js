var searchData=
[
  ['_7econnectiondialog_323',['~ConnectionDialog',['../class_connection_dialog.html#a43281efe3677803bce4e84c46b1f43b8',1,'ConnectionDialog']]],
  ['_7ewidget_324',['~Widget',['../class_widget.html#aa24f66bcbaaec6d458b0980e8c8eae65',1,'Widget']]]
];
